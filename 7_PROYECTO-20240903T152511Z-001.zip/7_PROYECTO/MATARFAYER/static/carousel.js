document.addEventListener('DOMContentLoaded', function() {
    let currentIndex = 0;
    const images = document.querySelectorAll('.carousel img');
    const totalImages = images.length;

    document.querySelector('.carousel-button-prev').addEventListener('click', showPrevImage);
    document.querySelector('.carousel-button-next').addEventListener('click', showNextImage);

    function showPrevImage() {
        images[currentIndex].classList.remove('active');
        currentIndex = (currentIndex === 0) ? totalImages - 1 : currentIndex - 1;
        images[currentIndex].classList.add('active');
    }

    function showNextImage() {
        images[currentIndex].classList.remove('active');
        currentIndex = (currentIndex === totalImages - 1) ? 0 : currentIndex + 1;
        images[currentIndex].classList.add('active');
    }

    // Inicializa el carrusel mostrando la primera imagen
    images[currentIndex].classList.add('active');
});
