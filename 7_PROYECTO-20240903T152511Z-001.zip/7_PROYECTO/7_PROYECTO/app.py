from flask import Flask, request, render_template, redirect, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configuración de la base de datos MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'Angel'
app.config['MYSQL_PASSWORD'] = '1234'
app.config['MYSQL_DB'] = 'car_marketplace'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        cur = mysql.connection.cursor()
        cur.execute('INSERT INTO users (username, email, password) VALUES (%s, %s, %s)',
                    (username, email, password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM users WHERE username = %s AND password = %s',
                    (username, password))
        user = cur.fetchone()
        cur.close()
        
        if user:
            return redirect(url_for('home'))
        else:
            return 'Incorrect username or password'
    return render_template('login.html')

@app.route('/edit_user', methods=('GET', 'POST'))
def edit_user():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET email = %s, password = %s WHERE username = %s',
                    (email, password, username))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('users'))
    return render_template('edit_user.html')

@app.route('/users')
def users():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM users')
    users = cur.fetchall()
    cur.close()
    return render_template('users.html', users=users)

@app.route('/contact', methods=('GET', 'POST'))
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        
        cur = mysql.connection.cursor()
        cur.execute('INSERT INTO contacts (name, email, message) VALUES (%s, %s, %s)',
                    (name, email, message))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('home'))
    return render_template('contact.html')

@app.route('/catalog')
def catalog():
    return render_template('catalog.html')

if __name__ == '__main__':
    app.run(debug=True)
